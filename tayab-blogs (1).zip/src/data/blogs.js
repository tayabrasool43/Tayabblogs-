const blogs = [
  {
    title: "AI Latest Tech News 2025",
    description: "New breakthrough in AI and robotics announced.",
    videoUrl: "https://www.youtube.com/embed/z3tc_bKX8Xg"
  },
  {
    title: "Mobile Innovation in 2025",
    description: "New flexible screen phones launched globally.",
    videoUrl: "https://www.youtube.com/embed/7XUQ1r5N5Lk"
  }
];

export default blogs;
